package com.example.unitconverter;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText inputValue;
    private Spinner conversionTypeSpinner;
    private TextView resultText;
    private Button convertButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        inputValue = findViewById(R.id.inputValue);
        conversionTypeSpinner = findViewById(R.id.spinner);
        resultText = findViewById(R.id.resultText);
        convertButton = findViewById(R.id.convertButton);

        convertButton.setOnClickListener(view -> {
            String inputString = inputValue.getText().toString();
            if (inputString.isEmpty()) {
                Toast.makeText(MainActivity.this, "Please enter a value", Toast.LENGTH_SHORT).show();
                return;
            }

            double input = Double.parseDouble(inputString);
            String conversionType = conversionTypeSpinner.getSelectedItem().toString();
            double result = 0;

            switch (conversionType) {
                case "Centimeters to Meters":
                    result = input / 100;
                    break;
                case "Meters to Centimeters":
                    result = input * 100;
                    break;
                case "Grams to Kilograms":
                    result = input / 1000;
                    break;
                case "Kilograms to Grams":
                    result = input * 1000;
                    break;
            }

            resultText.setText("Result: " + result);
        });
    }
}
